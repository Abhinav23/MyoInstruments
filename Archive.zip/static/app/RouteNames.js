define(function() {
  return {
    HOME: 'home'
  };
});

