define(function() {
  return {
    'Crash 1': 0,
    'Hat 1': 1,
    'Kick 1': 2,
    'Kick 2': 3,
    'Snare 1': 4,
    'Guitar': 5,
    'Violin': 6,
    'Bass 1': 7,
    'Bass 2': 8,
    'Synth': 9
  };
});
